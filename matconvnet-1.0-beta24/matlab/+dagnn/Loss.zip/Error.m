%PDIST vl_nnpdist dagnn wrapper
%  Accepts 2 or 3 inputs, where third input is used as variable
%  'instanceWeights' parameter. Derivatives for the 3rd input are not
%  computed.
%  By default aggregates the element-wise loss.
classdef Error < dagnn.Loss
  properties
%     loss	= 'psnr'
%     ignoreAverage   = true
  end

  methods
    function outputs = forward(obj, inputs, params)
      switch obj.loss
        case 'psnr'
          outputs{1} = psnr(gather(inputs{2}(:)), gather(inputs{1}(:)), 255) ;
        case 'mse'
          outputs{1} = immse(gather(inputs{2}(:)), gather(inputs{1}(:))) ;
        otherwise
          error('Invalid number of inputs');
      end
      obj.average = outputs{1};
    end

    function obj = Error(varargin)
      obj.load(varargin) ;
    end
  end
end
